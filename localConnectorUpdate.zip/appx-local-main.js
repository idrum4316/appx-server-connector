var localConnectorVersionStr = "6.0.0.19011401";
var localConnectorVersionNum = 60000.19011401;

global.dnd = null;//global is shared between windows
global.filedialog = null;

var win = require('nw.gui').Window.get().on('closed', function () {
    alert('closed');
});

var gui = require('nw.gui');
var win1 = gui.Window.get();
win1.hide();

var WebSocketServer = require('ws').Server;
var fs = require('fs');
var path = require('path');
var request = require('request');

var wss = new WebSocketServer({ host: "localhost", port: 3013 });

wss.on('connection', function (ws) {

    console.log("user connected:  ");

    ws.on('message', function (message) {
        var ms;
        var g;

        try {
            ms = JSON.parse(message);
            g = true;
        } catch (appxerror) {
            console.log(appxerror);
            g = false;
        }

        try {
            if (g) {

                if (ms.cmd == 'dnd') {

                    //check if a window has already been opened
                    if (!global.dnd) {

                        global.dnd = {
                            data: ms.data,
                            entries: [],
                        };

                        //process.execPath is the location of our running nw executable
                        global.dir = path.dirname(process.execPath);
                        global.dnd.log = {
                            line: 0,
                            file: path.join(global.dir, 'appxloconwdnd.log')
                        };
                        function dndLog(str) {
                            try {
                                var gdl = global.dnd.log;
                                gdl.line++;
                                str = "[" + gdl.line + "]\r\n" + str + "\r\n";
                                if (gdl.line == 1)
                                    fs.writeFileSync(gdl.file, str);
                                else
                                    fs.appendFileSync(gdl.file, str);
                            } catch (ex) { alert('dndLog: ' + ex); }
                        }

                        function dndSend() {
                            if (global.dnd.entries.length > 0) {
                                var ms = {
                                    data: global.dnd.entries,
                                    hasdata: "yes",
                                    haserrors: "no",
                                    type: "LOCALOS-DND"
                                };
                                dndLog('JSON: ' + JSON.stringify(ms));
                                ws.send(JSON.stringify(ms));
                            }
                            global.dnd = null;
                        }

                        var file = path.join(global.dir, 'AppxTools.exe'); dndLog('file: ' + file);
                        if (process.platform.indexOf('win') != -1 && fs.existsSync(file)) {
                            //run windows .net dnd to support outlook
                            var args = [global.dnd.data.wDnD];
                            var opts = { maxBuffer: 200 * 1024 * 10 };
                            require('child_process').execFile(file, args, opts, function (error, stdout, stderr) {
                                if (error) {
                                    dndLog('error: ' + error);
                                    alert('.NET DnD error: ' + error);
                                } else {
                                    //parse all the lines from standard output
                                    dndLog("stdout:\r\n" + stdout);
                                    var lines = stdout.split("\r\n");
                                    var entry = null;
                                    var gdd = global.dnd.data;
                                    for (var i = 0; i < lines.length; i++) {
                                        //entries separated by blank line
                                        if (i == 0 || lines[i - 1] == '' || i + 1 == lines.length) {
                                            if (i != 0) global.dnd.entries.push(entry);
                                            entry = {
                                                'row': gdd.wPosY,
                                                'col': gdd.wPosX,
                                                'path': '',
                                                'name': '',
                                                'ext': '',
                                                'mtype': '',
                                                'size': 0,
                                                'props': [],
                                                'parentType': gdd.wPrnt
                                            };
                                        }
                                        //properties separated by semicolumn
                                        var col = lines[i].indexOf(':');
                                        if (col > 0) {
                                            var label = lines[i].substr(0, col);
                                            if (label == 'type') label = 'mtype';
                                            var value = lines[i].substr(col + 2);
                                            if (entry.hasOwnProperty(label)) {
                                                entry[label] = value;
                                            } else if (value != '') {//otherwise a property
                                                entry.props.push({ 'name': label, 'value': value });
                                            }
                                        }
                                    }
                                    dndSend();
                                }
                            });


                        } else {//not windows, don't use .net solution

                            // Load native UI library
                            var gui = require('nw.gui');
                            var h = 110, w = 110;
                            var new_win = gui.Window.open('dnd.htm', {
                                "frame": false,
                                "height": h,
                                "position": "mouse",
                                "show": true,
                                "show_in_taskbar": false,
                                "width": w
                            }, function (win) {
                                // Release the 'win' object here after the new window is closed.
                                win.on('closed', function () {
                                    dndSend();
                                    win = null;
                                });
                            });
                        }
                    }

                } else if (ms.cmd == 'file-dialog-nw') {
                    //check if a window has already been opened
                    if (!global.filedialog) {

                        global.filedialog = {
                            data: ms.data,
                            filename: ""
                        };

                        // Load native UI library
                        var gui = require('nw.gui');
                        var h = 1, w = 1;

                        // Create a new window and get it
                        var new_win = gui.Window.open('file-dialog.htm', {
                            "frame": false,
                            "height": h,
                            "position": "mouse",
                            "show": true,
                            "show_in_taskbar": false,
                            "always_on_top": true,
                            "focus": true,
                            "width": w
                        }, function (win) {
                            // Release the 'win' object here after the new window is closed.
                            win.on('closed', function () {
                                var ms = {
                                    data: [global.filedialog.filename],
                                    hasdata: "yes",
                                    haserrors: "no",
                                    type: "LOCALOS-FILE-DIALOG"
                                };
                                ws.send(JSON.stringify(ms));

                                global.filedialog = null;
                                win = null;
                            });
                        });
                    }
                } else if (ms.cmd == 'openfile') {
                    try {
                        var mFileName = ms.args[0];
                        var mongoFileName = mFileName.replace(/ /g, "_");
                        var url = ms.protocol + "://" + ms.mongoHost + ":" + ms.port + ms.httpPath + "/upload/" + ms.uid + "_" + ms.pid + "/" + encodeURI(mongoFileName);
                        var rs = fs.createReadStream(mFileName);
                        var rPost = request.post(url)
                            .on('error', function (err) {
                                ms.hasdata = "no";
                                ms.haserror = "yes";
                                ms.error = err;
                                ms.type = "LOCALOS-ERROR";
                                ws.send(JSON.stringify(ms));
                                console.log(err);
                            })
                            .on('response', function (response) {
                                if (response.statusCode === 201) {
                                    var ms = {
                                        cmd: 'appxMongoToEngine',
                                        args: [],
                                        handler: "appxreceivefilehandler",
                                        type: "LOCALOS-OPENFILE",
                                        fileName: mongoFileName,
                                        data: null
                                    };
                                    ws.send(JSON.stringify(ms));
                                }
                            });
                        rs.pipe(rPost);
                    } catch (e) {
                        console.log(e);
                        console.log(e.stack);
                    }
                } else if (ms.cmd == 'openimage') {
                    fs.readFile(ms.args[0], function (err, data) {

                        if (!err) {
                            ms.data = data;
                            ms.hasdata = "yes";
                            ms.haserrors = "no";
                            ms.type = "LOCALOS-OPENIMAGE";

                            ws.send(JSON.stringify(ms));
                        } else {
                            ms.hasdata = "no";
                            ms.haserror = "yes";
                            ms.error = err;
                            ms.type = "LOCALOS-ERROR";
                            ws.send(JSON.stringify(ms));
                            console.log(err);
                        }

                    });

                } else if (ms.cmd == 'runoscmd') {

                    try {
                        var spawn = require('child_process').spawn,
                            ls = spawn(ms.args[0], ms.args.splice(1, ms.args.length));

                        ls.stdout.on('data', function (data) {
                            ms.data = data;
                            ms.haserrors = "no";
                            ms.hasdata = "yes";
                            ms.type = "LOCALOS-RUNCOMMAND";
                            ws.send(JSON.stringify(ms));
                        });

                        ls.stderr.on('data', function (data) {
                            ms.data = data;
                            ms.haserrors = "yes";
                            ms.hasdata = "yes";
                            ms.type = "LOCALOS-ERROR";
                            ws.send(JSON.stringify(ms));
                        });

                        ls.on('close', function (code) {
                            ms.data = code;
                            ms.haserrors = "no";
                            ms.hasdata = "yes";
                            ms.type = "LOCALOS-ERROR";
                            ws.send(JSON.stringify(ms));
                        });

                        ls.on('exit', function (code) {
                            ms.data = code;
                            ms.haserrors = "no";
                            ms.hasdata = "yes";
                            ms.type = "LOCALOS-RUNCOMMAND";
                            ws.send(JSON.stringify(ms));
                        });

                        ls.on('error', function (data) {
                            ms.data = data;
                            ms.haserrors = "no";
                            ms.hasdata = "yes";
                            ms.type = "LOCALOS-RUNCOMMAND";
                            ws.send(JSON.stringify(ms));
                        });

                    } catch (e) {
                        console.log("error in runoscmd:  " + e);
                    }

                } else if (ms.cmd == 'execoscmd') {

                    var exec = require('child_process');
                    var child;

                    child = exec.execSync(ms.args[0]);
                    ms.hasdata = "yes";
                    ms.data = child;
                    ms.type = "LOCALOS-EXECOMMAND";

                    ws.send(JSON.stringify(ms));


                } else if (ms.cmd == 'setclipboard') {

                    try {
                        var cb = require('copy-paste');

                        cb.copy(ms.args[0]);

                        ms.haserrors = "no";
                        ms.hasdata = "yes";
                        ms.data = "CLIPBOARD WAS SET TO:  " + ms.args[0];
                        ms.type = "LOCALOS-SETCLIPBOARD";
                    } catch (e) {
                        console.log('set clipboard error: ' + e);
                        ms.haserrors = "yes";
                        ms.data = e;
                        ms.type = "LOCALOS-ERROR";
                    }

                    ws.send(JSON.stringify(ms));

                } else if (ms.cmd == 'getclipboard') {

                    try {
                        var cb = require('copy-paste');
                        cb.paste(function (a, b) {
                            ms.haserrors = "no";
                            ms.hasdata = "yes";
                            ms.data = b;
                            ms.type = "LOCALOS-GETCLIPBOARD";
                            ws.send(JSON.stringify(ms));
                        });
                    } catch (e) {
                        console.log('get clipboard error: ' + e);
                        ms.haserrors = "yes";
                        ms.data = e;
                        ms.type = "LOCALOS-ERROR";
                        ws.send(JSON.stringify(ms));
                    }

                } else if (ms.cmd == 'createfile') {

                    var timer = 0;
                    var currfile = ms.args[0];
                    var emparray = [];
                    var b = new Buffer(emparray);

                    var newdir = path.dirname(currfile.filename.trim());
                    if (newdir) {
                        if (!fs.existsSync(newdir)) {
                            fs.mkdirSync(newdir, 0777, true);
                        }
                    }

                    setTimeout(function () {
                        if (fs.existsSync(newdir)) {
                            fs.writeFile(currfile.filename.trim(), b, function (err) {
                                if (!err) {
                                    ms.data = { "file": currfile.filename.trim(), "saved": true };
                                    ms.hasdata = "yes";
                                    ms.haserrors = "no";
                                    ms.type = "LOCALOS-CREATEFILE";
                                    ws.send(JSON.stringify(ms));
                                } else {
                                    ms.data = err;
                                    ms.hasdata = "yes";
                                    ms.haserror = "yes";
                                    ms.error = err;
                                    ms.type = "LOCALOS-CREATEFILE";
                                    ws.send(JSON.stringify(ms));
                                }
                            });
                        } else {
                            ms.data = "Directory does not exist and cannot be created!!!";
                            ms.hasdata = "yes";
                            ms.haserror = "yes";
                            ms.error = "Directory does not exist and cannot be created!!!";
                            ms.type = "LOCALOS-CREATEFILE";
                            ws.send(JSON.stringify(ms));
                        }
                    }, timer);

                } else if (ms.cmd == 'appendfile') {

                    var timer = 0;
                    var currfile = ms.args[0];
                    var b = new Buffer(currfile.filedata, "base64");

                    try {
                        fs.appendFileSync(currfile.filename.trim(), b);
                        ms.data = { "file": currfile.filename.trim(), "appended": true, "length": currfile.filedata.length };
                        ms.hasdata = "yes";
                        ms.haserrors = "no";
                        ms.type = "LOCALOS-APPENDFILE";
                        ws.send(JSON.stringify(ms));
                    }
                    catch (ex) {
                        ms.data = ex;
                        ms.hasdata = "yes";
                        ms.haserror = "yes";
                        ms.error = ex;
                        ms.type = "LOCALOS-APPENDFILE";
                        ws.send(JSON.stringify(ms));
                    }
                    /*
                    **Creates cache file directory structure that appx uses
                    */
                } else if (ms.cmd == 'localoscreatedir') {
                    var arrayDir = ["Data", "Drop", "Print", "Resource", "Token"];
                    var index = ms.args[0].indexOf(".appx");
                    var baseDir = ms.args[0].substring(0, index - 1);
                    var arrayAppxPath = ms.args[0].substring(index).split("\\");
                    if (arrayAppxPath.length === 0) {
                        arrayAppxPath = ms.args[0].substring(index).split("\/");
                    }

                    for (var i = 0; i < arrayAppxPath.length; i++) {
                        baseDir = (baseDir + "/" + arrayAppxPath[i].replace(/\//g,""));
                        if (!fs.existsSync(baseDir)) {
                            fs.mkdirSync(baseDir, 0777, true);
                        }
                    }

                    for (var i = 0; i < arrayDir.length; i++) {
                        var newdir = (ms.args[0] + arrayDir[i]);
                        if (!fs.existsSync(newdir)) {
                            fs.mkdirSync(newdir, 0777, true);
                        }
                    }

                } else if (ms.cmd == 'localosinit') {

                    // This appxinit message provides the opportunity to push down any assets needed on the client

                    /*We require at least node webkit version 0.12.3. If version does
                    **not meet minimum version then we exit so user will be prompted to
                    **download newer version.*/
                    var gui = require('nw.gui');
                    var nwVersion = process.versions['node-webkit'].split(".");
                    if (!(nwVersion[0] > 0 || nwVersion[1] >= 12)) {
                        var h = 250, w = 400;
                        var new_win = gui.Window.open('upgrade.html', {
                            "frame": false,
                            "height": h,
                            "position": "mouse",
                            "show": true,
                            "show_in_taskbar": false,
                            "width": w
                        });
                    }

                    //send user enviroment data
                    var pe = process.env;
                    pe.currentworkingdirectory = process.cwd();
                    pe.localConnectorVersionStr = localConnectorVersionStr;
                    pe.localConnectorVersionNum = localConnectorVersionNum;
                    ms.data = pe;
                    ms.hasdata = "yes";
                    ms.haserror = "no";
                    ms.type = "LOCALOS-ENVIRONMENT";
                    ws.send(JSON.stringify(ms));


                } else if (ms.cmd == 'update') {

                    var currfile = ms.args[0];
                    var b = new Buffer(currfile.filedata);

                    try {
                        fs.unlinkSync(currfile.filename.trim(), function (err) { });
                    }
                    catch (e) {
                    }

                    fs.writeFileSync(currfile.filename.trim(), b);


                    var DecompressZip = require('decompress-zip');
                    var unzipper = new DecompressZip(currfile.filename.trim())

                    unzipper.on('error', function (err) {
                        console.log('Caught an error = ' + err);
                    });

                    unzipper.on('extract', function (log) {

                        var ms = {
                            data: [],
                            hasdata: "no",
                            haserrors: "no",
                            type: "LOCALOS-RELOAD"
                        };
                        ws.send(JSON.stringify(ms));

                        console.log("updating local connector: " + currfile.filename.trim());
                        wss.close();
                        document.location.reload(true);
                    });


                    unzipper.extract({
                        path: '.',
                        filter: function (file) {
                            return file.type !== "SymbolicLink";
                        }
                    });

                } else {
                    console.log('no message');
                }
            }

        } catch (appxerror2) {
            console.log(appxerror2);
            if (JSON.stringify(appxerror2).indexOf("mkdir") !== -1) {
                ms.data = appxerror2;
                ms.hasdata = "yes";
                ms.haserror = "yes";
                ms.error = err;
                ms.type = "LOCALOS-CREATEFILE";
                ws.send(JSON.stringify(ms));
            }
        }

    });

    ws.send(JSON.stringify('connection accepted on localhost:3013'));
});

function hton16(i) {
    return [
        0xff & (i >> 8),
        0xff & (i >> 0)
    ];
}

function hton32(i) {
    return [
        0xff & (i >> 24),
        0xff & (i >> 16),
        0xff & (i >> 8),
        0xff & (i >> 0)
    ];
}

function toUTF8Array(str) {
    var utf8 = [];
    for (var i = 0; i < str.length; i++) {
        var charcode = str.charCodeAt(i);
        if (charcode < 0x80) utf8.push(charcode);
        else if (charcode < 0x800) {
            utf8.push(0xc0 | (charcode >> 6),
                0x80 | (charcode & 0x3f));
        }
        else if (charcode < 0xd800 || charcode >= 0xe000) {
            utf8.push(0xe0 | (charcode >> 12),
                0x80 | ((charcode >> 6) & 0x3f),
                0x80 | (charcode & 0x3f));
        }
        // surrogate pair
        else {
            i++;
            // UTF-16 encodes 0x10000-0x10FFFF by
            // subtracting 0x10000 and splitting the
            // 20 bits of 0x0-0xFFFFF into two halves
            charcode = 0x10000 + (((charcode & 0x3ff) << 10) | (str.charCodeAt(i) & 0x3ff))
            utf8.push(0xf0 | (charcode >> 18),
                0x80 | ((charcode >> 12) & 0x3f),
                0x80 | ((charcode >> 6) & 0x3f),
                0x80 | (charcode & 0x3f));
        }
    }
    return utf8;
}
console.log("Server Running...");
