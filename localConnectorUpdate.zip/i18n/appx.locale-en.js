function loadLanguage() {
    let langText = {
        authDialog: {
            appName: "APPX",
            codeText: "<span class='app-name'>APPX</span> Access Code",
            headerText: "<span class='app-name'>APPX</span> Local Access Request",
            dialogText: "The <span class='app-name'></span> application running in your browser would like access to your desktop.  " +
            "The browser session requesting access will display the code shown below.  " +
            "To allow this access confirm the codes match and click the Allow button.  To deny access click the Deny button.",
            allowText: "Allow",
            denyText: "Deny"
        }
    };

    return langText;
}
