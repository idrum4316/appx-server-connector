function loadLanguage() {
    let langText = {
        authDialog: {
            appName: "APPX",
            headerText: "<span class='app-name'>APPX</span> Verzoek om lokale toegang",
            codeText: "<span class='app-name'>APPX</span> Toegangscode",
            dialogText: "De <span class='app-name'></span> toepassing die in uw browser wordt uitgevoerd, zou toegang tot uw bureaublad willen.  " +
            "De browsersessie die toegang vraagt, geeft de onderstaande code weer.  " +
            "Om deze toegang toe te staan, bevestigt u dat de codes overeenkomen en klikt u op de knop Toestaan. Om de toegang te weigeren, klikt u op de knop Weigeren.",
            allowText: "Toestaan",
            denyText: "Ontkennen"
        }
    };

    return langText;
}
